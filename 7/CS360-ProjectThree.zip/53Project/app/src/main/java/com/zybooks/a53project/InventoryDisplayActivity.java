package com.zybooks.a53project;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;

public class InventoryDisplayActivity extends AppCompatActivity {
    private InventoryDatabaseHelper databaseHelper;
    private GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_display);

        databaseHelper = new InventoryDatabaseHelper(this);
        gridView = findViewById(R.id.gridView);

        // Populate grid with inventory items
        populateGrid();
    }

    private void populateGrid() {
        Cursor cursor = databaseHelper.getAllItems();

        String[] fromColumns = {InventoryDatabaseHelper.COLUMN_ITEM_NAME, InventoryDatabaseHelper.COLUMN_ITEM_QUANTITY};
        int[] toViews = {R.id.itemNameTextView, R.id.itemQuantityTextView};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.grid_item, cursor, fromColumns, toViews, 0);
        gridView.setAdapter(adapter);
    }
}

