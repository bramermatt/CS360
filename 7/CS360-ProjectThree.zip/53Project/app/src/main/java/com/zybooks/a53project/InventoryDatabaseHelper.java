package com.zybooks.a53project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;




public class InventoryDatabaseHelper extends SQLiteOpenHelper {
    public static final String COLUMN_ITEM_NAME = "TEXT";
    public static final String COLUMN_ITEM_QUANTITY = "TEXT";
    private static final String DATABASE_NAME = "inventory_db";
    private static final int DATABASE_VERSION = 1;

    // Table and columns
    private static final String TABLE_ITEMS = "items";
    private static final String COLUMN_ID = "id";

    // Create table SQL
    private static final String CREATE_TABLE_ITEMS =
            "CREATE TABLE " + TABLE_ITEMS + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_ITEM_NAME + " TEXT,"
                    + COLUMN_ITEM_QUANTITY + " INTEGER"
                    + ")";

    public InventoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_ITEMS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // Add a new inventory item to the database
    public boolean addItem(String itemName, int itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_ITEM_QUANTITY, itemQuantity);
        long result = db.insert(TABLE_ITEMS, null, values);
        return result != -1;
    }

    // Get all inventory items from the database
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_ITEMS, null, null, null, null, null, null);
    }
}

