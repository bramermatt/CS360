package com.zybooks.a53project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}


// Matthew Bramer - Aug 9, 2023

//Have I kept my classes concise?
// utilizing camelCase!

//Is my style consistent throughout the code?
// Yes!

//Would my naming conventions make sense to anyone else who looked at my code?
// hopefully.

//Do my in-line comments contain enough useful information?
// I believe so, I didn't do in-line comments for everything.