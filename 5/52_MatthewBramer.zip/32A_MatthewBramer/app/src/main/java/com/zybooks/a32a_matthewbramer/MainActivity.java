package com.zybooks.a32a_matthewbramer;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText nameText;
    private Button buttonSayHello;
    private TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        nameText = findViewById(R.id.editTextName);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        // Set a TextWatcher to enable/disable the button based on nameText content
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Enable the button if there is text in nameText, otherwise disable it
                buttonSayHello.setEnabled(charSequence.length() > 0);
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }

    // onClick method for the "Say Hello" button
    public void SayHello(View view) {
        String name = nameText.getText().toString().trim();

        // Check if the nameText is not empty
        if (!name.isEmpty()) {
            // Display "Hello" and the contents of nameText to textGreeting
            textGreeting.setText("Hello, " + name);
        } else {
            // Display "You must enter a name" to textGreeting
            textGreeting.setText("You must enter a name");
        }
    }
}



