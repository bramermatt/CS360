package com.zybooks.a53project;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {
    private List<String> dataItems;
    private ArrayAdapter<String> dataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        GridView dataGridView = findViewById(R.id.dataGridView);

        // Initialize the data list
        dataItems = new ArrayList<>();
        dataItems.add("Data 1");
        dataItems.add("Data 2");
        dataItems.add("Data 3");
        // Add more data items as needed

        // Create an adapter for the GridView
        dataAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataItems);
        dataGridView.setAdapter(dataAdapter);

        // Set item click listener for the GridView
        dataGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = dataItems.get(position);
                // Implement logic to edit the selected item's value here
                Toast.makeText(DataDisplayActivity.this, "Clicked: " + selectedItem, Toast.LENGTH_SHORT).show();
            }
        });

        // Set item long click listener for the GridView
        dataGridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = dataItems.get(position);
                // Implement logic to delete the selected item from the grid here
                dataItems.remove(position);
                dataAdapter.notifyDataSetChanged();
                Toast.makeText(DataDisplayActivity.this, "Deleted: " + selectedItem, Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        Button addDataButton = findViewById(R.id.addDataButton);
        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement logic to add new data to the grid here
                dataItems.add("New Data");
                dataAdapter.notifyDataSetChanged();
                Toast.makeText(DataDisplayActivity.this, "Added New Data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

