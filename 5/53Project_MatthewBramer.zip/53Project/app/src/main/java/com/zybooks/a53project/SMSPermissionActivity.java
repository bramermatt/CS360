package com.zybooks.a53project;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SMSPermissionActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_SMS = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        Button requestPermissionButton = findViewById(R.id.requestPermissionButton);
        requestPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Request SMS permission
                requestSMSPermission();
            }
        });
    }

    private void requestSMSPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                // Permission already granted, show a Toast message indicating permission granted.
                Toast.makeText(this, "SMS Permission Already Granted", Toast.LENGTH_SHORT).show();
                // Proceed with sending automated system notifications
                sendAutomatedSystemNotifications();
            } else {
                // Request SMS permission
                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SMS);
            }
        } else {
            // For devices below Android M, SMS permission is granted by default.
            // Proceed with sending automated system notifications
            sendAutomatedSystemNotifications();
        }
    }

    private void sendAutomatedSystemNotifications() {
        // Implement your logic to send automated system notifications based on options chosen in Project One.
        // For demonstration, we'll show a Toast message for each type of notification.
        Toast.makeText(this, "Low Inventory Notification", Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "Upcoming Event Notification", Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "Goal Weight Reached Notification", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, show a Toast message indicating permission granted.
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
                // Proceed with sending automated system notifications
                sendAutomatedSystemNotifications();
            } else {
                // Permission denied, show a Toast message indicating permission denied.
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

