package com.zybooks.a53_project_matthewbramer;
// work done 2024.5.27

// updating this dataDisplayActivity.java to add the input for the data, not a static input.
// updating to the spreadsheet style!
// totally new look to the dataDisplay!
// added a logout button.


import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import java.util.ArrayList;

public class DataDisplayActivity extends AppCompatActivity {
    private ArrayList<String> dataList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize data list
        dataList = new ArrayList<>();

        // Create and set the custom adapter for GridView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        GridView dataGridView = findViewById(R.id.dataGridView);
        dataGridView.setAdapter(adapter);

        // Add sample data for demonstration
        dataList.add("Item A");
        dataList.add("10");
        dataList.add("2023-07-30");
        dataList.add("Item B");
        dataList.add("5");
        dataList.add("2023-07-31");
        adapter.notifyDataSetChanged();

        // Button for adding data to the grid
        Button addDataButton = findViewById(R.id.addDataButton);
        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Inflate the dialog layout
                LayoutInflater inflater = LayoutInflater.from(v.getContext());
                View dialogView = inflater.inflate(R.layout.dialog_input, null);

                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                builder.setView(dialogView)
                        .setTitle("Add New Item")
                        .setPositiveButton("Add", (dialog, which) -> {
                            // Get user input from the dialog
                            EditText editTextItem = dialogView.findViewById(R.id.editTextItem);
                            EditText editTextValue = dialogView.findViewById(R.id.editTextValue);
                            EditText editTextDate = dialogView.findViewById(R.id.editTextDate);

                            String item = editTextItem.getText().toString();
                            String value = editTextValue.getText().toString();
                            String date = editTextDate.getText().toString();

                            // Add the new item to the data list
                            dataList.add(item);
                            dataList.add(value);
                            dataList.add(date);
                            adapter.notifyDataSetChanged();
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                        .create()
                        .show();
            }
        });

        // Button for logging out
        Button logoutButton = findViewById(R.id.logoutButton);
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the logout logic here
                // For example, you could finish the activity or navigate to a login screen
                Intent logoutIntent = new Intent(DataDisplayActivity.this, LoginActivity.class);
                startActivity(logoutIntent);
                finish(); // Optionally, finish this activity to prevent the user from going back
            }
        });
    }
}
