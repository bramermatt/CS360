package com.zybooks.a53_project_matthewbramer;

import static android.widget.Toast.*;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class PermissionPromptActivity extends AppCompatActivity {
    private static final int REQUEST_SMS_PERMISSION = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_prompt);

        Button askPermissionButton = findViewById(R.id.askPermissionButton);
        askPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check if the user has already granted SMS permission
                if (checkSmsPermission()) {
                    // If SMS permission is already granted, proceed with sending notifications
                    sendNotifications();
                } else {
                    // If SMS permission is not granted, request the permission
                    requestSmsPermission();
                }
            }
        });
    }

    private boolean checkSmsPermission() {
        // Check if the SMS permission is granted
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        }
        return true; // If the device is pre-Marshmallow, assume the permission is granted
    }

    private void requestSmsPermission() {
        // Request the SMS permission from the user
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission is granted, proceed with sending notifications
                sendNotifications();
            } else {
                // Permission is denied, show a message to the user
                makeText(this, "SMS permission is required to send notifications.", LENGTH_SHORT).show();
            }
        }
    }

    private void sendNotifications() {
        // Implement your notification logic here
        // Based on your Project One, send low inventory, upcoming event, or goal weight notifications
        // For simplicity, we'll just show a Toast message for each type of notification.

        makeText(this, "Sending low inventory notification...", LENGTH_SHORT).show();
        makeText(this, "Sending upcoming event notification...", LENGTH_SHORT).show();
        makeText(this, "Sending goal weight notification...", LENGTH_SHORT).show();
    }
}
