package com.zybooks.a53_project_matthewbramer;

// Matthew Bramer - Login Activity Page
// originally created Aug 2023.
// New work May 2024.

import static android.widget.Toast.*;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class LoginActivity extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;

    // Hardcoded username and password for demonstration
    private static final String DEMO_USERNAME = "demo_user";
    private static final String DEMO_PASSWORD = "demo_pass";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredUsername = usernameEditText.getText().toString();
                String enteredPassword = passwordEditText.getText().toString();

                // Validate the entered credentials
                if (enteredUsername.equals(DEMO_USERNAME) && enteredPassword.equals(DEMO_PASSWORD)) {
                    // Successful login, show a Toast message indicating success
                    Toast.makeText(LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();

                    // After successful login, start the DataDisplayActivity
                    Intent intent = new Intent(LoginActivity.this, DataDisplayActivity.class);
                    startActivity(intent);

                    // Finish the LoginActivity to prevent the user from going back to the login screen using the back button
                    finish();
                } else {
                    // Invalid credentials, show a Toast message indicating failure
                    Toast.makeText(LoginActivity.this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button createAccountButton = findViewById(R.id.createAccountButton);
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredUsername = usernameEditText.getText().toString();
                String enteredPassword = passwordEditText.getText().toString();

                // Check if the entered username and password are valid
                if (isValidUsername(enteredUsername) && isValidPassword(enteredPassword)) {
                    // Check if the user already exists
                    HashMap<Object, Object> userAccounts = new HashMap<>();
                    if (!userAccounts.containsKey(enteredUsername)) {
                        // Add the new user account
                        userAccounts.put(enteredUsername, enteredPassword);

                        // Account created, show a Toast message indicating success
                        makeText(LoginActivity.this, "Account Created!", LENGTH_SHORT).show();

                    } else {
                        // User already exists, show a Toast message indicating failure
                        makeText(LoginActivity.this, "User already exists. Try logging in.", LENGTH_SHORT).show();
                    }
                } else {
                    // Invalid username or password, show a Toast message indicating failure
                    makeText(LoginActivity.this, "Invalid username or password.", LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isValidUsername(String username) {
        // Implement your validation logic here
        return !username.isEmpty();
    }

    private boolean isValidPassword(String password) {
        // Implement your validation logic here
        return !password.isEmpty();
    }
}
